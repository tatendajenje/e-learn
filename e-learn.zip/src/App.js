import "./App.css";
import RoutesMain from "./routes";

function App() {
  return <RoutesMain />;
}

export default App;
