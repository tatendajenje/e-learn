 export {default as Home}  from './home'
 export {default as Register}  from './register'
 export {default as Contact}  from './contact'
 export {default as AboutUs}  from './about-us'
 export {default as Login}  from './login'
 export {default as Courses}  from './courses'
 export {default as Cart} from './cart'
 export {default as Error} from './error'

 