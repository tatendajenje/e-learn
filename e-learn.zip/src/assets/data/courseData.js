import img from "./../images/blockchain.jpg";
import img1 from "./../images/cyber-security.jpg";
import img2 from "./../images/continuous-improvement.jpg";
import img3 from "./../images/machine-learning.jpg";
import img4 from "./../images/project-management.png";
import img5 from "./../images/artificial-intelligence.jpg";
export const courses = [
  {
    id: 1,
    name: "Blockchain",
    amount: 1,
    price:'0',
    users: 23,
    views: 1234,
    rating: "4.9",
    image: img,
    author: "Brian Nhondo",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        id:1,
        sectionName: "Module 01",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
      {
        id:1,
        sectionName: "Module 02",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
      {
        id:1,
        sectionName: "Module 03",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
  {
    id: 2,
    name: "Cyber Security",
    price:'50.00',
    amount: 1,
    users: 235,
    views: 567,
    rating: "3.8",
    image: img1,
    author: "Alex Bay",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        sectionName: "Introduction",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
  {
    id: 3,
    name: "Continuous Improvement",
    price:"0",
    amount: 1,
    users: 4556,
    views: 349,
    rating: "4.3",
    image: img2,
    author: "Nomsa Chal",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        sectionName: "Introduction",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
  {
    id: 4,
    name: "Machine Learning",
    price:'39.99',
    amount: 1,
    users: 468,
    views: 567,
    rating: "3.5",
    image: img3,
    author: "James Eith",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        sectionName: "Introduction",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
  {
    id: 5,
    name: "Project Management",
    amount: 1,
    price:'0',
    users: 468,
    views: 567,
    rating: "3.5",
    image: img4,
    author: "Catrina Paulo",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        sectionName: "Introduction",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
  {
    id: 6,
    name: "Artificial Intelligence",
    amount: 1,
    price:"49.99",
    users: 300,
    views: 3567,
    rating: "3.5",
    image: img5,
    author: "Marry Yu",
    category: "Development",
    about:"Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
    skillsLearned:[
      "Technology",
      "Security",
      "Development",
      "Technology",
      "Security",
      "Development",
      
    ],
    requirement:[
      "f you have any questions ",
      "ontact us is through our form.",
      "espond inless than 48 hours, but",
      "the best  to contact us is through our form",
      "Security",
      "Develoontact us is through our formpment",
      
    ],
    sections: [
      {
        sectionName: "Introduction",
        sectionContent: [
          {
            id: 1,
            topicName: "Introduction",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "2 minutes",
          },
          {
            id: 2,
            topicName: "Five Factors of block",
            topicContent:
              "Lore If you have any questions or just want to say hello, the best  to contact us is through our form. We do our best to respond inless than 48 hours, but if it takes a little longer, please forgive us! We read each message and distribute it internally to ensure that you end up speaking to the right person. You can alsocheck out our Help section, where ",
            duration: "4 minutes",
          },
        ],
      },
    ],
  },
];

export const coursesCategory = [
  {
    name: "Development",
    image: img3,
  },
  {
    name: "Business",
    image: img5,
  },
  {
    name: "Security",
    image: img4,
  },
  {
    name: "Technology",
    image: img2,
    author: "James Eith",
  },
  {
    name: "Photography",
    image: img,
    author: "Catrina Paulo",
  },
  {
    name: "Music",
    image: img1,
  },
];


export function getCourses() {
    return courses;
  }